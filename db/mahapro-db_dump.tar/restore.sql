--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.8 (Ubuntu 14.8-1.pgdg22.04+1)
-- Dumped by pg_dump version 14.8 (Ubuntu 14.8-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "mahapro-db";
--
-- Name: mahapro-db; Type: DATABASE; Schema: -; Owner: kati
--

CREATE DATABASE "mahapro-db" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C.UTF-8';


ALTER DATABASE "mahapro-db" OWNER TO kati;

\connect -reuse-previous=on "dbname='mahapro-db'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: check_user_limit(integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.check_user_limit(p_user_id integer, p_discount_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    row_count integer;
    user_limit integer;
BEGIN
    SELECT COUNT(*)
    INTO row_count
    FROM transaction
    WHERE p_user_id = user_id
      AND discount_id = p_discount_id;

    SELECT claims_per_user
    INTO user_limit
    FROM discount
    WHERE discount_id = p_discount_id;

    RETURN row_count > user_limit;
END;
$$;


ALTER FUNCTION public.check_user_limit(p_user_id integer, p_discount_id integer) OWNER TO postgres;

--
-- Name: get_current_unix_timestamp(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_current_unix_timestamp() RETURNS bigint
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN EXTRACT(EPOCH FROM NOW())::DOUBLE PRECISION;
END;
$$;


ALTER FUNCTION public.get_current_unix_timestamp() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: discount; Type: TABLE; Schema: public; Owner: kati
--

CREATE TABLE public.discount (
    discount_id integer NOT NULL,
    business_id integer NOT NULL,
    is_online boolean NOT NULL,
    claims_per_user integer NOT NULL,
    minimum_spend integer,
    discount_title_text_id integer NOT NULL,
    expiry_date double precision NOT NULL,
    link_online character varying(255),
    is_percentage boolean,
    amount integer
);


ALTER TABLE public.discount OWNER TO kati;

--
-- Name: get_discounts_by_branches(double precision, double precision); Type: FUNCTION; Schema: public; Owner: kati
--

CREATE FUNCTION public.get_discounts_by_branches(longitude double precision, latitude double precision) RETURNS SETOF public.discount
    LANGUAGE plpgsql
    AS $$
DECLARE
    REC discount;
BEGIN
    RETURN QUERY
    SELECT d.*
    FROM discount d
             INNER JOIN (SELECT discount_id
                         FROM allowed_branch ab
                                  INNER JOIN list_branches_by_distance(longitude, latitude) branches
                                             ON ab.branch_id = branches.branch_id) b
                        ON d.discount_id = b.discount_id
    WHERE d.expiry_date > get_current_unix_timestamp();
END;
$$;


ALTER FUNCTION public.get_discounts_by_branches(longitude double precision, latitude double precision) OWNER TO kati;

--
-- Name: get_discounts_by_random(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_discounts_by_random() RETURNS SETOF public.discount
    LANGUAGE plpgsql
    AS $$
DECLARE
    rec discount;
BEGIN
    RETURN QUERY
   SELECT *
    FROM discount
    ORDER BY random()
    LIMIT 10;
END;
$$;


ALTER FUNCTION public.get_discounts_by_random() OWNER TO postgres;

--
-- Name: get_discounts_for_user(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_discounts_for_user(p_user_id integer) RETURNS SETOF public.discount
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
        SELECT *
        FROM get_discounts_by_branches(
                (SELECT st_x(location) FROM user_location WHERE user_id = p_user_id ORDER BY time_received DESC LIMIT 1),
                (SELECT st_y(location) FROM user_location WHERE user_id = p_user_id ORDER BY time_received DESC LIMIT 1)
            );
END;
$$;


ALTER FUNCTION public.get_discounts_for_user(p_user_id integer) OWNER TO postgres;

--
-- Name: business_user; Type: TABLE; Schema: public; Owner: kati
--

CREATE TABLE public.business_user (
    firebase_user_id text NOT NULL,
    role_id smallint NOT NULL,
    business_user_id text NOT NULL,
    business_id integer NOT NULL
);


ALTER TABLE public.business_user OWNER TO kati;

--
-- Name: insert_business_user(text, text, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.insert_business_user(p_business_user_id text, p_firebase_user_id text, p_business_id integer, p_role_id integer) RETURNS public.business_user
    LANGUAGE plpgsql
    AS $$
    DECLARE inserted_row business_user;
    BEGIN
       INSERT INTO business_user(firebase_user_id, role_id, business_user_id, business_id)
        VALUES (p_firebase_user_id, p_role_id, p_business_user_id, p_business_id)
        RETURNING * INTO inserted_row;

       RETURN inserted_row;
    END;
$$;


ALTER FUNCTION public.insert_business_user(p_business_user_id text, p_firebase_user_id text, p_business_id integer, p_role_id integer) OWNER TO postgres;

--
-- Name: transaction; Type: TABLE; Schema: public; Owner: kati
--

CREATE TABLE public.transaction (
    transaction_id integer NOT NULL,
    user_id integer NOT NULL,
    discount_id integer NOT NULL,
    discount_coupon_code text,
    used_on double precision,
    branch_id integer,
    status text DEFAULT 'claimed'::text NOT NULL
);


ALTER TABLE public.transaction OWNER TO kati;

--
-- Name: insert_transaction(text, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.insert_transaction(p_discount_coupon_code text, p_user_id integer, p_discount_id integer) RETURNS public.transaction
    LANGUAGE plpgsql
    AS $$
DECLARE
    inserted_row "transaction";
BEGIN
    INSERT INTO "transaction" (discount_coupon_code, user_id, discount_id)
    VALUES (p_discount_coupon_code, p_user_id, p_discount_id)
    RETURNING * INTO inserted_row;

    RETURN inserted_row;
END;
$$;


ALTER FUNCTION public.insert_transaction(p_discount_coupon_code text, p_user_id integer, p_discount_id integer) OWNER TO postgres;

--
-- Name: user; Type: TABLE; Schema: public; Owner: kati
--

CREATE TABLE public."user" (
    user_id integer NOT NULL,
    first_name character varying(255) NOT NULL,
    last_name character varying(255) NOT NULL,
    personal_email character varying(255) NOT NULL,
    school_email character varying(255) NOT NULL,
    date_of_birth double precision NOT NULL,
    university_id smallint,
    firebase_user_id character varying(255) NOT NULL,
    email_verified boolean DEFAULT false NOT NULL
);


ALTER TABLE public."user" OWNER TO kati;

--
-- Name: insert_user(character varying, character varying, character varying, character varying, double precision, smallint, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.insert_user(p_first_name character varying, p_last_name character varying, p_personal_email character varying, p_school_email character varying, p_date_of_birth double precision, p_university_id smallint, p_firebase_user_id character varying) RETURNS public."user"
    LANGUAGE plpgsql
    AS $$
DECLARE
    inserted_row public."user";
BEGIN
    INSERT INTO public."user" (
                               first_name, last_name, personal_email, school_email, date_of_birth, university_id, firebase_user_id
    )
    VALUES (p_first_name, p_last_name, p_personal_email, p_school_email, p_date_of_birth, p_university_id, p_firebase_user_id)
    RETURNING * INTO inserted_row;

    RETURN inserted_row;
END;
$$;


ALTER FUNCTION public.insert_user(p_first_name character varying, p_last_name character varying, p_personal_email character varying, p_school_email character varying, p_date_of_birth double precision, p_university_id smallint, p_firebase_user_id character varying) OWNER TO postgres;

--
-- Name: branch; Type: TABLE; Schema: public; Owner: kati
--

CREATE TABLE public.branch (
    branch_id integer NOT NULL,
    business_id integer NOT NULL,
    location public.geometry,
    phone_number text,
    branch_name_text_id integer NOT NULL
);


ALTER TABLE public.branch OWNER TO kati;

--
-- Name: list_branches_by_distance(double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.list_branches_by_distance(p_longitude double precision, p_latitude double precision) RETURNS SETOF public.branch
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
        SELECT b.*
        FROM branch AS b
        ORDER BY ST_DistanceSphere(ST_MakePoint(p_longitude, p_latitude), ST_GeomFromWKB(b.location)) ASC;
END;
$$;


ALTER FUNCTION public.list_branches_by_distance(p_longitude double precision, p_latitude double precision) OWNER TO postgres;

--
-- Name: business; Type: TABLE; Schema: public; Owner: kati
--

CREATE TABLE public.business (
    business_id integer NOT NULL,
    phone_number double precision NOT NULL,
    email text NOT NULL,
    business_type_id integer NOT NULL,
    contact_name text,
    business_info_text_id integer,
    business_slogan_text_id integer,
    business_name_text_id integer
);


ALTER TABLE public.business OWNER TO kati;

--
-- Name: search_retailer_by_location(double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_retailer_by_location(p_longitude double precision, p_latitude double precision) RETURNS SETOF public.business
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
        SELECT DISTINCT ON (b.business_id) bu.*
        FROM list_branches_by_distance(p_longitude, p_latitude) b
                 JOIN business bu ON b.business_id = bu.business_id;
END;
$$;


ALTER FUNCTION public.search_retailer_by_location(p_longitude double precision, p_latitude double precision) OWNER TO postgres;

--
-- Name: search_retailer_by_query(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_retailer_by_query(p_query text) RETURNS SETOF public.business
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
        SELECT b.*
        FROM business b
                 JOIN translation t ON b.business_name_text_id = t.text_id
        WHERE t.translation ILIKE '%' || p_query || '%'
           OR to_tsvector('english', t.translation) @@ to_tsquery('english', p_query);
END;
$$;


ALTER FUNCTION public.search_retailer_by_query(p_query text) OWNER TO postgres;

--
-- Name: verify_user(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.verify_user(p_user_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE "user"
    SET email_verified = TRUE
    WHERE user_id = p_user_id;
END;
$$;


ALTER FUNCTION public.verify_user(p_user_id integer) OWNER TO postgres;

--
-- Name: allowed_branch; Type: TABLE; Schema: public; Owner: kati
--

CREATE TABLE public.allowed_branch (
    allowed_branch_id integer NOT NULL,
    discount_id integer NOT NULL,
    branch_id integer NOT NULL
);


ALTER TABLE public.allowed_branch OWNER TO kati;

--
-- Name: allowed_branch_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.allowed_branch_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.allowed_branch_seq OWNER TO postgres;

--
-- Name: allowed_branches_allowed_branches_id_seq; Type: SEQUENCE; Schema: public; Owner: kati
--

ALTER TABLE public.allowed_branch ALTER COLUMN allowed_branch_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.allowed_branches_allowed_branches_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: bonus_discount_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bonus_discount_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bonus_discount_seq OWNER TO postgres;

--
-- Name: branch_branch_id_seq; Type: SEQUENCE; Schema: public; Owner: kati
--

ALTER TABLE public.branch ALTER COLUMN branch_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.branch_branch_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: branch_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.branch_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.branch_seq OWNER TO postgres;

--
-- Name: business_business_id_seq; Type: SEQUENCE; Schema: public; Owner: kati
--

ALTER TABLE public.business ALTER COLUMN business_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.business_business_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: business_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.business_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.business_seq OWNER TO postgres;

--
-- Name: business_type; Type: TABLE; Schema: public; Owner: kati
--

CREATE TABLE public.business_type (
    business_type_id integer NOT NULL,
    business_type_name character varying(255) NOT NULL
);


ALTER TABLE public.business_type OWNER TO kati;

--
-- Name: business_type_business_type_id_seq; Type: SEQUENCE; Schema: public; Owner: kati
--

ALTER TABLE public.business_type ALTER COLUMN business_type_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.business_type_business_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: business_type_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.business_type_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.business_type_seq OWNER TO postgres;

--
-- Name: discount_discount_id_seq; Type: SEQUENCE; Schema: public; Owner: kati
--

ALTER TABLE public.discount ALTER COLUMN discount_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.discount_discount_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: discount_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.discount_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.discount_seq OWNER TO postgres;

--
-- Name: discount_type; Type: TABLE; Schema: public; Owner: kati
--

CREATE TABLE public.discount_type (
    discount_type_id text NOT NULL,
    discount_type_name_id integer NOT NULL
);


ALTER TABLE public.discount_type OWNER TO kati;

--
-- Name: discount_type_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.discount_type_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.discount_type_seq OWNER TO postgres;

--
-- Name: favorite_retailer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.favorite_retailer (
    favorite_retailer_id integer NOT NULL,
    user_id integer NOT NULL,
    business_id integer NOT NULL
);


ALTER TABLE public.favorite_retailer OWNER TO postgres;

--
-- Name: favorite_retailer_favorite_retailer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.favorite_retailer ALTER COLUMN favorite_retailer_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.favorite_retailer_favorite_retailer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: favorite_retailer_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.favorite_retailer_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.favorite_retailer_seq OWNER TO postgres;

--
-- Name: fixedamount_discount_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.fixedamount_discount_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fixedamount_discount_seq OWNER TO postgres;

--
-- Name: language; Type: TABLE; Schema: public; Owner: kati
--

CREATE TABLE public.language (
    language_id smallint NOT NULL,
    language_code text NOT NULL
);


ALTER TABLE public.language OWNER TO kati;

--
-- Name: language_language_id_seq; Type: SEQUENCE; Schema: public; Owner: kati
--

ALTER TABLE public.language ALTER COLUMN language_id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.language_language_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: percentage_discount_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.percentage_discount_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.percentage_discount_seq OWNER TO postgres;

--
-- Name: post; Type: TABLE; Schema: public; Owner: kati
--

CREATE TABLE public.post (
    post_id integer NOT NULL,
    business_id integer NOT NULL,
    post_datetime double precision NOT NULL,
    post_content_text_id integer NOT NULL
);


ALTER TABLE public.post OWNER TO kati;

--
-- Name: post_post_id_seq; Type: SEQUENCE; Schema: public; Owner: kati
--

ALTER TABLE public.post ALTER COLUMN post_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.post_post_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: post_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.post_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.post_seq OWNER TO postgres;

--
-- Name: role; Type: TABLE; Schema: public; Owner: kati
--

CREATE TABLE public.role (
    role_id smallint NOT NULL,
    role_name text NOT NULL,
    can_claim_coupon boolean DEFAULT false NOT NULL,
    can_post_discount boolean DEFAULT false NOT NULL,
    can_edit_discount boolean DEFAULT false NOT NULL,
    can_edit_business_user boolean DEFAULT false NOT NULL,
    can_edit_business_info boolean DEFAULT false NOT NULL
);


ALTER TABLE public.role OWNER TO kati;

--
-- Name: role_role_id_seq; Type: SEQUENCE; Schema: public; Owner: kati
--

ALTER TABLE public.role ALTER COLUMN role_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.role_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: text_content; Type: TABLE; Schema: public; Owner: kati
--

CREATE TABLE public.text_content (
    text_id integer NOT NULL
);


ALTER TABLE public.text_content OWNER TO kati;

--
-- Name: text_content_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.text_content_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.text_content_seq OWNER TO postgres;

--
-- Name: text_content_text_id_seq; Type: SEQUENCE; Schema: public; Owner: kati
--

ALTER TABLE public.text_content ALTER COLUMN text_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.text_content_text_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: transaction_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.transaction_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transaction_seq OWNER TO postgres;

--
-- Name: translation; Type: TABLE; Schema: public; Owner: kati
--

CREATE TABLE public.translation (
    text_id integer NOT NULL,
    language_id smallint NOT NULL,
    translation text,
    translation_id bigint NOT NULL
);


ALTER TABLE public.translation OWNER TO kati;

--
-- Name: translation_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.translation_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.translation_seq OWNER TO postgres;

--
-- Name: translation_translation_id_seq; Type: SEQUENCE; Schema: public; Owner: kati
--

ALTER TABLE public.translation ALTER COLUMN translation_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.translation_translation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: university; Type: TABLE; Schema: public; Owner: kati
--

CREATE TABLE public.university (
    university_id smallint NOT NULL,
    university_name text NOT NULL,
    university_country text NOT NULL
);


ALTER TABLE public.university OWNER TO kati;

--
-- Name: university_domain; Type: TABLE; Schema: public; Owner: kati
--

CREATE TABLE public.university_domain (
    university_domain_id integer NOT NULL,
    university_id smallint NOT NULL,
    domain character varying(255) NOT NULL
);


ALTER TABLE public.university_domain OWNER TO kati;

--
-- Name: university_domain_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.university_domain_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.university_domain_seq OWNER TO postgres;

--
-- Name: university_domain_university_domain_id_seq; Type: SEQUENCE; Schema: public; Owner: kati
--

ALTER TABLE public.university_domain ALTER COLUMN university_domain_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.university_domain_university_domain_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: university_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.university_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.university_seq OWNER TO postgres;

--
-- Name: university_university_id_seq; Type: SEQUENCE; Schema: public; Owner: kati
--

ALTER TABLE public.university ALTER COLUMN university_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.university_university_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_discount_transaction_user_discount_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: kati
--

ALTER TABLE public.transaction ALTER COLUMN transaction_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.user_discount_transaction_user_discount_transaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_favorite_retailer; Type: TABLE; Schema: public; Owner: kati
--

CREATE TABLE public.user_favorite_retailer (
    user_id integer NOT NULL,
    business_id integer
);


ALTER TABLE public.user_favorite_retailer OWNER TO kati;

--
-- Name: user_location; Type: TABLE; Schema: public; Owner: kati
--

CREATE TABLE public.user_location (
    user_location_id integer NOT NULL,
    user_id integer NOT NULL,
    location public.geometry NOT NULL,
    time_received double precision NOT NULL
);


ALTER TABLE public.user_location OWNER TO kati;

--
-- Name: user_location_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_location_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_location_seq OWNER TO postgres;

--
-- Name: user_location_user_location_id_seq; Type: SEQUENCE; Schema: public; Owner: kati
--

ALTER TABLE public.user_location ALTER COLUMN user_location_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.user_location_user_location_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_retailer_clicks; Type: TABLE; Schema: public; Owner: kati
--

CREATE TABLE public.user_retailer_clicks (
    user_id integer NOT NULL,
    retailer_id integer NOT NULL,
    time_clicked double precision NOT NULL
);


ALTER TABLE public.user_retailer_clicks OWNER TO kati;

--
-- Name: user_search; Type: TABLE; Schema: public; Owner: kati
--

CREATE TABLE public.user_search (
    user_id integer NOT NULL,
    query text,
    longitude double precision,
    latitude double precision,
    business_type_id integer,
    user_search_id integer NOT NULL,
    "timestamp" double precision NOT NULL
);


ALTER TABLE public.user_search OWNER TO kati;

--
-- Name: user_search_user_search_id_seq; Type: SEQUENCE; Schema: public; Owner: kati
--

ALTER TABLE public.user_search ALTER COLUMN user_search_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.user_search_user_search_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_seq OWNER TO postgres;

--
-- Name: user_user_id_seq; Type: SEQUENCE; Schema: public; Owner: kati
--

ALTER TABLE public."user" ALTER COLUMN user_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.user_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: allowed_branch; Type: TABLE DATA; Schema: public; Owner: kati
--

\i $$PATH$$/4536.dat

--
-- Data for Name: branch; Type: TABLE DATA; Schema: public; Owner: kati
--

\i $$PATH$$/4531.dat

--
-- Data for Name: business; Type: TABLE DATA; Schema: public; Owner: kati
--

\i $$PATH$$/4529.dat

--
-- Data for Name: business_type; Type: TABLE DATA; Schema: public; Owner: kati
--

\i $$PATH$$/4523.dat

--
-- Data for Name: business_user; Type: TABLE DATA; Schema: public; Owner: kati
--

\i $$PATH$$/4568.dat

--
-- Data for Name: discount; Type: TABLE DATA; Schema: public; Owner: kati
--

\i $$PATH$$/4534.dat

--
-- Data for Name: discount_type; Type: TABLE DATA; Schema: public; Owner: kati
--

\i $$PATH$$/4532.dat

--
-- Data for Name: favorite_retailer; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4558.dat

--
-- Data for Name: language; Type: TABLE DATA; Schema: public; Owner: kati
--

\i $$PATH$$/4526.dat

--
-- Data for Name: post; Type: TABLE DATA; Schema: public; Owner: kati
--

\i $$PATH$$/4541.dat

--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: kati
--

\i $$PATH$$/4567.dat

--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4272.dat

--
-- Data for Name: text_content; Type: TABLE DATA; Schema: public; Owner: kati
--

\i $$PATH$$/4525.dat

--
-- Data for Name: transaction; Type: TABLE DATA; Schema: public; Owner: kati
--

\i $$PATH$$/4538.dat

--
-- Data for Name: translation; Type: TABLE DATA; Schema: public; Owner: kati
--

\i $$PATH$$/4527.dat

--
-- Data for Name: university; Type: TABLE DATA; Schema: public; Owner: kati
--

\i $$PATH$$/4515.dat

--
-- Data for Name: university_domain; Type: TABLE DATA; Schema: public; Owner: kati
--

\i $$PATH$$/4519.dat

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: kati
--

\i $$PATH$$/4516.dat

--
-- Data for Name: user_favorite_retailer; Type: TABLE DATA; Schema: public; Owner: kati
--

\i $$PATH$$/4539.dat

--
-- Data for Name: user_location; Type: TABLE DATA; Schema: public; Owner: kati
--

\i $$PATH$$/4521.dat

--
-- Data for Name: user_retailer_clicks; Type: TABLE DATA; Schema: public; Owner: kati
--

\i $$PATH$$/4564.dat

--
-- Data for Name: user_search; Type: TABLE DATA; Schema: public; Owner: kati
--

\i $$PATH$$/4563.dat

--
-- Name: allowed_branch_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.allowed_branch_seq', 1, false);


--
-- Name: allowed_branches_allowed_branches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kati
--

SELECT pg_catalog.setval('public.allowed_branches_allowed_branches_id_seq', 75, true);


--
-- Name: bonus_discount_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bonus_discount_seq', 1, false);


--
-- Name: branch_branch_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kati
--

SELECT pg_catalog.setval('public.branch_branch_id_seq', 50, true);


--
-- Name: branch_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.branch_seq', 1, false);


--
-- Name: business_business_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kati
--

SELECT pg_catalog.setval('public.business_business_id_seq', 3, true);


--
-- Name: business_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.business_seq', 1, false);


--
-- Name: business_type_business_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kati
--

SELECT pg_catalog.setval('public.business_type_business_type_id_seq', 8, true);


--
-- Name: business_type_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.business_type_seq', 1, false);


--
-- Name: discount_discount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kati
--

SELECT pg_catalog.setval('public.discount_discount_id_seq', 18, true);


--
-- Name: discount_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.discount_seq', 1, false);


--
-- Name: discount_type_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.discount_type_seq', 1, false);


--
-- Name: favorite_retailer_favorite_retailer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.favorite_retailer_favorite_retailer_id_seq', 23, true);


--
-- Name: favorite_retailer_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.favorite_retailer_seq', 1, false);


--
-- Name: fixedamount_discount_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fixedamount_discount_seq', 1, false);


--
-- Name: language_language_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kati
--

SELECT pg_catalog.setval('public.language_language_id_seq', 2, true);


--
-- Name: percentage_discount_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.percentage_discount_seq', 1, false);


--
-- Name: post_post_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kati
--

SELECT pg_catalog.setval('public.post_post_id_seq', 1, false);


--
-- Name: post_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.post_seq', 1, false);


--
-- Name: role_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kati
--

SELECT pg_catalog.setval('public.role_role_id_seq', 5, true);


--
-- Name: text_content_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.text_content_seq', 1, false);


--
-- Name: text_content_text_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kati
--

SELECT pg_catalog.setval('public.text_content_text_id_seq', 80, true);


--
-- Name: transaction_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transaction_seq', 1, false);


--
-- Name: translation_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.translation_seq', 1, false);


--
-- Name: translation_translation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kati
--

SELECT pg_catalog.setval('public.translation_translation_id_seq', 81, true);


--
-- Name: university_domain_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.university_domain_seq', 1, false);


--
-- Name: university_domain_university_domain_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kati
--

SELECT pg_catalog.setval('public.university_domain_university_domain_id_seq', 136, true);


--
-- Name: university_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.university_seq', 1, false);


--
-- Name: university_university_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kati
--

SELECT pg_catalog.setval('public.university_university_id_seq', 68, true);


--
-- Name: user_discount_transaction_user_discount_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kati
--

SELECT pg_catalog.setval('public.user_discount_transaction_user_discount_transaction_id_seq', 36, true);


--
-- Name: user_location_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_location_seq', 1, false);


--
-- Name: user_location_user_location_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kati
--

SELECT pg_catalog.setval('public.user_location_user_location_id_seq', 99, true);


--
-- Name: user_search_user_search_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kati
--

SELECT pg_catalog.setval('public.user_search_user_search_id_seq', 81, true);


--
-- Name: user_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_seq', 1, false);


--
-- Name: user_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kati
--

SELECT pg_catalog.setval('public.user_user_id_seq', 22, true);


--
-- Name: allowed_branch allowed_branches_pkey; Type: CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.allowed_branch
    ADD CONSTRAINT allowed_branches_pkey PRIMARY KEY (allowed_branch_id);


--
-- Name: branch branch_pkey; Type: CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.branch
    ADD CONSTRAINT branch_pkey PRIMARY KEY (branch_id);


--
-- Name: business business_pkey; Type: CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.business
    ADD CONSTRAINT business_pkey PRIMARY KEY (business_id);


--
-- Name: business_type business_type_name_unique; Type: CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.business_type
    ADD CONSTRAINT business_type_name_unique UNIQUE (business_type_name);


--
-- Name: business_type business_type_pkey; Type: CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.business_type
    ADD CONSTRAINT business_type_pkey PRIMARY KEY (business_type_id);


--
-- Name: business_user business_user_pkey; Type: CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.business_user
    ADD CONSTRAINT business_user_pkey PRIMARY KEY (business_user_id);


--
-- Name: discount discount_pkey; Type: CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.discount
    ADD CONSTRAINT discount_pkey PRIMARY KEY (discount_id);


--
-- Name: discount_type discount_type_pkey; Type: CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.discount_type
    ADD CONSTRAINT discount_type_pkey PRIMARY KEY (discount_type_id);


--
-- Name: university_domain domain_unique; Type: CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.university_domain
    ADD CONSTRAINT domain_unique UNIQUE (domain);


--
-- Name: favorite_retailer favorite_retailer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_retailer
    ADD CONSTRAINT favorite_retailer_pkey PRIMARY KEY (favorite_retailer_id);


--
-- Name: user firebase_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT firebase_user_id_unique UNIQUE (firebase_user_id);


--
-- Name: language language_pkey; Type: CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.language
    ADD CONSTRAINT language_pkey PRIMARY KEY (language_id);


--
-- Name: post post_pkey; Type: CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.post
    ADD CONSTRAINT post_pkey PRIMARY KEY (post_id);


--
-- Name: role role_name_unique; Type: CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_name_unique UNIQUE (role_name);


--
-- Name: role role_pkey; Type: CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_pkey PRIMARY KEY (role_id);


--
-- Name: user school_email_unique; Type: CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT school_email_unique UNIQUE (school_email);


--
-- Name: text_content text_content_pkey; Type: CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.text_content
    ADD CONSTRAINT text_content_pkey PRIMARY KEY (text_id);


--
-- Name: translation text_id_language_id_unique; Type: CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.translation
    ADD CONSTRAINT text_id_language_id_unique UNIQUE (text_id, language_id);


--
-- Name: translation translation_pkey; Type: CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.translation
    ADD CONSTRAINT translation_pkey PRIMARY KEY (translation_id);


--
-- Name: university_domain university_domain_pkey; Type: CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.university_domain
    ADD CONSTRAINT university_domain_pkey PRIMARY KEY (university_domain_id);


--
-- Name: university university_name_unique; Type: CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.university
    ADD CONSTRAINT university_name_unique UNIQUE (university_name);


--
-- Name: university university_pkey; Type: CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.university
    ADD CONSTRAINT university_pkey PRIMARY KEY (university_id);


--
-- Name: transaction user_discount_transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT user_discount_transaction_pkey PRIMARY KEY (transaction_id);


--
-- Name: favorite_retailer user_id_business_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_retailer
    ADD CONSTRAINT user_id_business_id_unique UNIQUE (user_id, business_id);


--
-- Name: user_location user_location_pkey; Type: CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.user_location
    ADD CONSTRAINT user_location_pkey PRIMARY KEY (user_location_id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (user_id);


--
-- Name: user_search user_search_pkey; Type: CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.user_search
    ADD CONSTRAINT user_search_pkey PRIMARY KEY (user_search_id);


--
-- Name: idx_business_name; Type: INDEX; Schema: public; Owner: kati
--

CREATE INDEX idx_business_name ON public.translation USING gin (to_tsvector('english'::regconfig, translation));


--
-- Name: transaction branch_id; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT branch_id FOREIGN KEY (branch_id) REFERENCES public.branch(branch_id);


--
-- Name: allowed_branch branch_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.allowed_branch
    ADD CONSTRAINT branch_id_fk FOREIGN KEY (branch_id) REFERENCES public.branch(branch_id);


--
-- Name: branch branch_name_text_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.branch
    ADD CONSTRAINT branch_name_text_id_fk FOREIGN KEY (branch_name_text_id) REFERENCES public.text_content(text_id) NOT VALID;


--
-- Name: branch business_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.branch
    ADD CONSTRAINT business_id_fk FOREIGN KEY (business_id) REFERENCES public.business(business_id);


--
-- Name: discount business_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.discount
    ADD CONSTRAINT business_id_fk FOREIGN KEY (business_id) REFERENCES public.business(business_id);


--
-- Name: user_favorite_retailer business_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.user_favorite_retailer
    ADD CONSTRAINT business_id_fk FOREIGN KEY (business_id) REFERENCES public.business(business_id);


--
-- Name: post business_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.post
    ADD CONSTRAINT business_id_fk FOREIGN KEY (business_id) REFERENCES public.business(business_id);


--
-- Name: favorite_retailer business_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_retailer
    ADD CONSTRAINT business_id_fk FOREIGN KEY (business_id) REFERENCES public.business(business_id) NOT VALID;


--
-- Name: business_user business_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.business_user
    ADD CONSTRAINT business_id_fk FOREIGN KEY (business_id) REFERENCES public.business(business_id) NOT VALID;


--
-- Name: user_retailer_clicks business_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.user_retailer_clicks
    ADD CONSTRAINT business_id_fk FOREIGN KEY (retailer_id) REFERENCES public.business(business_id) NOT VALID;


--
-- Name: business business_info_text_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.business
    ADD CONSTRAINT business_info_text_id_fk FOREIGN KEY (business_info_text_id) REFERENCES public.text_content(text_id);


--
-- Name: business business_slogan_text_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.business
    ADD CONSTRAINT business_slogan_text_id_fk FOREIGN KEY (business_slogan_text_id) REFERENCES public.text_content(text_id) NOT VALID;


--
-- Name: business business_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.business
    ADD CONSTRAINT business_type_id_fk FOREIGN KEY (business_type_id) REFERENCES public.business_type(business_type_id);


--
-- Name: user_search business_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.user_search
    ADD CONSTRAINT business_type_id_fk FOREIGN KEY (business_type_id) REFERENCES public.business_type(business_type_id) NOT VALID;


--
-- Name: allowed_branch discount_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.allowed_branch
    ADD CONSTRAINT discount_id_fk FOREIGN KEY (discount_id) REFERENCES public.discount(discount_id);


--
-- Name: transaction discount_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT discount_id_fk FOREIGN KEY (discount_id) REFERENCES public.discount(discount_id);


--
-- Name: discount discount_title_text_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.discount
    ADD CONSTRAINT discount_title_text_id_fk FOREIGN KEY (discount_title_text_id) REFERENCES public.text_content(text_id);


--
-- Name: discount_type discount_type_name_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.discount_type
    ADD CONSTRAINT discount_type_name_id_fk FOREIGN KEY (discount_type_name_id) REFERENCES public.text_content(text_id) NOT VALID;


--
-- Name: translation language_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.translation
    ADD CONSTRAINT language_id_fk FOREIGN KEY (language_id) REFERENCES public.language(language_id);


--
-- Name: post post_content_text_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.post
    ADD CONSTRAINT post_content_text_id_fk FOREIGN KEY (post_content_text_id) REFERENCES public.text_content(text_id);


--
-- Name: business_user role_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.business_user
    ADD CONSTRAINT role_id_fk FOREIGN KEY (role_id) REFERENCES public.role(role_id);


--
-- Name: translation text_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.translation
    ADD CONSTRAINT text_id_fk FOREIGN KEY (text_id) REFERENCES public.text_content(text_id);


--
-- Name: user university_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT university_id_fk FOREIGN KEY (university_id) REFERENCES public.university(university_id);


--
-- Name: university_domain university_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.university_domain
    ADD CONSTRAINT university_id_fk FOREIGN KEY (university_id) REFERENCES public.university(university_id);


--
-- Name: transaction user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(user_id);


--
-- Name: user_favorite_retailer user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.user_favorite_retailer
    ADD CONSTRAINT user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(user_id);


--
-- Name: user_location user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.user_location
    ADD CONSTRAINT user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(user_id) NOT VALID;


--
-- Name: user_search user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.user_search
    ADD CONSTRAINT user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(user_id) NOT VALID;


--
-- Name: favorite_retailer user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_retailer
    ADD CONSTRAINT user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(user_id) NOT VALID;


--
-- Name: user_retailer_clicks user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kati
--

ALTER TABLE ONLY public.user_retailer_clicks
    ADD CONSTRAINT user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(user_id) NOT VALID;


--
-- PostgreSQL database dump complete
--

